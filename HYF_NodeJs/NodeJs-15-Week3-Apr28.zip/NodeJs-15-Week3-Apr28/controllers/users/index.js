const routes=require('./routes')

module.exports=routes
